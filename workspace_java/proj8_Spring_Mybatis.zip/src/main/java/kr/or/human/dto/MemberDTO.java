package kr.or.human.dto;

import lombok.Data;

//@Getter
//@Setter
//@ToString
//@RequiredArgsConstructor
//@EqualsAndHashCode
@Data
public class MemberDTO {

	private String userID;
	private String userPW;
	private int age;
	private String userName;
	
}
